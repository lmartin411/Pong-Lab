// A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import java.awt.Color;
import java.awt.Graphics;

public class Block
{
	private int xPos;
	private int yPos;
	private int width;
	private int height;

	private Color color;

	public Block()
	{


	}

	// add other Block constructors - x , y , width, height, color
   // you can find what constructors you need by looking at BlockTestOne and BlockTestTwo






	public void setColor( Color col )
	{


	}

	public void setPos( int x, int y )
	{
	
	}
	
	public void setX( int x )
	{
	
	}
	
	public void setY( int y )
	{
	
	}
	
	// add the other set methods
   // you can see what modifier methods to add by looking at the instance variables

	public int getX()
	{
	
	}
	
	public int getY()
	{
	
	}

	
	
	//add the other get methods
   // you can see what accessor methods to add by looking at the instance variables


	public void draw(Graphics window)
	{
    //uncomment after you write the set and get methods
    //window.setColor(color);
    //window.fillRect(getX(), getY(), getWidth(), getHeight());
	}

   // use the draw method provided about to figure out how to complete this method
	public void draw(Graphics window, Color col)
	{


	}

   // review the equals method from book and library
   // show me your completed equals method please
	public boolean equals(Object obj)
	{




		return false;
	}

 

	//add a toString() method  - x , y , width, height, color
}
